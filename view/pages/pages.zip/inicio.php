<div class="content-header row mt-5">
</div>
<div class="content-body"><!-- ICO Token &  Distribution-->
    <div class="row match-height">
        <div class="col-xl-8 col-12">
            <div class="card card-transparent">
                <div class="card-header card-header-transparent py-20">
                    <div class="btn-group dropdown">
                        <h6>Proximamente</h6>
                    </div>
                </div>
                <div id="ico-token-supply-demand-chart" class="height-300"></div>
            </div>
        </div>
        <div class="col-xl-4 col-lg-12">
            <div class="card card-transparent">
                <div class="card-header card-header-transparent">
                    <h6 class="card-title">Proximamente</h6>
                </div>
                <div class="card-content">
                    <div id="token-distribution-chart" class="height-200 donut donutShadow"></div>
                    <div class="card-body">
                        <div class="row mx-0">
                            <ul class="token-distribution-list col-md-6 mb-0">
                                <li class="crowd-sale">Venta colectiva <span class="float-right text-muted">41%</span></li>
                                <li class="team">Equipo <span class="float-right text-muted">18%</span></li>
                                <li class="advisors">Asesores <span class="float-right text-muted">15%</span></li>
                            </ul>
                            <ul class="token-distribution-list col-md-6 mb-0">
                                <li class="project-reserve">Reserva del proyecto <span class="float-right text-muted">10%</span></li>
                                <li class="master-nodes">Nodos maestros <span class="float-right text-muted">8%</span></li>
                                <li class="program">Programa <span class="float-right text-muted">8%</span></li>
                            </ul>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>