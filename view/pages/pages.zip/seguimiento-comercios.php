<div class="content-header row mt-4">
    <div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
        <h3 class="content-header-title mb-0 d-inline-block">Seguimiento de ventas</h3>
        <p class="mb-4">Seguimiento en tiempo real de pedidos.</p>
    </div>
</div>

<!--=====================================================
=                     RELACION - LIMA                  =
========================================================-->

<?php if ($_SESSION["rol"] == "Administrador" || $_SESSION["rol"] == "Supervisor-lima") : ?>

    <div class="bg-dark py-1"><h6 class="content-header-title mb-0 d-inline-block ml-2 text-white">Ventas en Lima</h6></div>
    
    <div class="embed-responsive embed-responsive-16by9">
        <div class="card-header py-3">
            <h5 class="m-0 font-weight-bold text-secondary">Ventas en Lima</h5>
        </div>
        <iframe src="https://lookerstudio.google.com/embed/reporting/0641c240-48eb-4363-9df4-3d1e31e186e4/page/K7mkD" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>

<?php endif ?>

<br><br>

<!--=====================================================
=                 RELACION - CHICLAYO                  =
========================================================-->
<?php if ($_SESSION["rol"] == "Administrador" || $_SESSION["rol"] == "Supervisor-chiclayo") : ?>
    <div class="bg-dark py-1"><h6 class="content-header-title mb-0 d-inline-block ml-2 text-white">Venta Iquitos</h6></div>

    <div class="embed-responsive embed-responsive-16by9">
        <div class="card-header py-3">
            <h5 class="m-0 font-weight-bold text-secondary">Ventas Chiclayo</h5>
        </div>
        <iframe src="https://lookerstudio.google.com/embed/reporting/0641c240-48eb-4363-9df4-3d1e31e186e4/page/K7mkD" frameborder="0" allowfullscreen></iframe>
    </div>

<?php endif ?>

<!--=====================================================
=                 RELACION - IQUITOS                   =
========================================================-->

<br><br>

<?php if ($_SESSION["rol"] == "Administrador" || $_SESSION["rol"] == "Supervisor-iquitos") : ?>

    <div class="bg-dark py-1"><h6 class="content-header-title mb-0 d-inline-block ml-2 text-white">Ventas Iquitos</h6></div>

    <div class="embed-responsive embed-responsive-16by9">
        <div class="card-header py-3">
            <h5 class="m-0 font-weight-bold text-secondary">Ventas Iquitos</h5>
        </div>
        <iframe class="embed-responsive-item" src="https://lookerstudio.google.com/embed/reporting/d5381c52-7fd8-47e2-957b-d3c3bb78f654/page/K7mkD" frameborder="0" style="border:0" allowfullscreen sandbox="allow-storage-access-by-user-activation allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox"></iframe>
    </div>


<?php endif ?>