<footer class="footer footer-static footer-transparent">
    <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2"><span class="float-md-left d-block d-md-inline-block">Copyright &copy; <script>
                document.write(new Date().getFullYear())
            </script> <a class="text-bold-800 grey darken-2" href="https://evangcorp.com/" target="_blank">Evag corp </a>, All rights reserved. </span><span class="float-md-right d-block d-md-inline-blockd-none d-lg-block">Desarrollado por Francisco Dev <i class="ft-heart pink"></i></span></p>
</footer>