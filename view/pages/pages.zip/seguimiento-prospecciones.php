
<div class="content-header row mt-4">
    <div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
        <h3 class="content-header-title mb-0 d-inline-block">Seguimiento de prospectos</h3>
        <p class="mb-4">Seguimiento en tiempo real de pedidos.</p>
    </div>
</div>

<!--=====================================================
=                     RELACION - LIMA                  =
========================================================-->

<?php if ($_SESSION["rol"] == "Administrador" || $_SESSION["rol"] == "Supervisor-lima") : ?>
    <div class="card shadow mb-4 contenedor-relevante">
        <div class="card-header py-3">
            <h5 class="m-0 font-weight-bold text-secondary">Prospectos Lima</h5>
        </div>
        <div class="card-body">
            <div class="embed-responsive embed-responsive-16by9">
                <iframe class="embed-responsive-item" src="https://lookerstudio.google.com/embed/reporting/01c38bae-802e-4b02-9125-d9509c41b129/page/x4ymD" frameborder="0" style="border:0" allowfullscreen sandbox="allow-storage-access-by-user-activation allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox"></iframe>
            </div>
        </div>
    </div>

<?php endif ?>

<!--=====================================================
=                 RELACION - CHICLAYO                  =
========================================================-->

<?php if ($_SESSION["rol"] == "Administrador" || $_SESSION["rol"] == "Supervisor-chiclayo") : ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h5 class="m-0 font-weight-bold text-secondary">Prospectos Chiclayo</h5>
        </div>
        <div class="card-body contenedor-relevante">
            <div class="embed-responsive embed-responsive-16by9">
                <iframe class="embed-responsive-item" src="https://lookerstudio.google.com/embed/reporting/e2ab3a9c-60e2-4e72-bb78-10bd6f9e8b6c/page/x4ymD" frameborder="0" style="border:0" allowfullscreen sandbox="allow-storage-access-by-user-activation allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox"></iframe>

            </div>
        </div>
    </div>

<?php endif ?>

<!--=====================================================
=                 RELACION - IQUITOS                   =
========================================================-->

<?php if ($_SESSION["rol"] == "Administrador" || $_SESSION["rol"] == "Supervisor-iquitos") : ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h5 class="m-0 font-weight-bold text-secondary">Prospectos Iquitos</h5>
        </div>
        <div class="card-body contenedor-relevante">
            <div class="embed-responsive embed-responsive-16by9">
                <iframe class="embed-responsive-item" src="https://lookerstudio.google.com/embed/reporting/c3db5261-b969-4e48-9150-fdd529f126e7/page/x4ymD" frameborder="0" style="border:0" allowfullscreen sandbox="allow-storage-access-by-user-activation allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox"></iframe>
            </div>
        </div>
    </div>

<?php endif ?>