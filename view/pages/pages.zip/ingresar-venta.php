
<div class="content-header row mt-4">
    <div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
        <h3 class="content-header-title mb-0 d-inline-block">Ingresar venta</h3>
        <p class="mb-4">Ingrese la ventas correspondientes.</p>
    </div>
</div>

