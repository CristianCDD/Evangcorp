<div class="content-header row mt-4">
    <div class="content-header-left col-md-8 col-12 mb-5 breadcrumb-new">
        <h3 class="content-header-title mb-0 d-inline-block">VALIDACIONES Y CARTAS</h3>
        <div class="row breadcrumbs-top d-inline-block">
            <div class="breadcrumb-wrapper col-12">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="inicio">ESCRITORIO</a>
                    </li>
                    <li class="breadcrumb-item active">carta ofertas
                    </li>
                </ol>
            </div>
        </div>
    </div>

</div>


<div class="card">
    <div class="card-content p-4">
        <div class="table-responsive">
            <table id="tabla-responsives" class="table table-hover table-xl mb-0 myTable display">
                <thead>
                    <tr>
                        <th class="border-top-0">#</th>
                        <th class="border-top-0">Hora de la llamada validadora</th>
                        <th class="border-top-0">Duración de la llamada</th>
                        <th class="border-top-0">Hora de activación del POS</th>
                        <th class="border-top-0">Vaucher y Carta</th>
                        <th class="border-top-0">Acciones</th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td>1</td>
                        <td>09:00:00 am</td>
                        <td>10 minutos</td>
                        <td>10:30:00 am</td>
                        <td>
                            <button class="btn btn-success"><i class="fas fa-image"></i> Vaucher</button>
                            <button class="btn btn-danger"><i class="fas fa-file-pdf"></i> Carta</button>
                        </td>
                        <td>
                            <!-- Botones de acciones -->
                            <div class="btn-group" role="group" aria-label="Acciones de usuario">
                                <button idUsuario="<?php echo $value["id_usuario"] ?>" type="button" class="btn btn-primary btn-xs btnEditarUsuarios" data-toggle="modal" data-target="#modalEditarUsuario"><i class="fa fa-edit"></i></button>
                                <button idUsuario="<?php echo $value["id_usuario"] ?>" type="button" class="btn btn-danger btn-xs btnEliminarUsuarios"><i class="fa fa-trash"></i></button>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>10:15:00 am</td>
                        <td>15 minutos</td>
                        <td>01:30:00 pm</td>
                        <td><button class="btn btn-success"><i class="fas fa-image"></i> Vaucher</button>
                            <button class="btn btn-danger"><i class="fas fa-file-pdf"></i> Carta</button>
                        </td>
                        <td>
                            <!-- Botones de acciones -->
                            <div class="btn-group" role="group" aria-label="Acciones de usuario">
                                <button idUsuario="<?php echo $value["id_usuario"] ?>" type="button" class="btn btn-primary btn-xs btnEditarUsuarios" data-toggle="modal" data-target="#modalEditarUsuario"><i class="fa fa-edit"></i></button>
                                <button idUsuario="<?php echo $value["id_usuario"] ?>" type="button" class="btn btn-danger btn-xs btnEliminarUsuarios"><i class="fa fa-trash"></i></button>
                            </div>
                        </td>
                    </tr>
                    <!-- Agrega más filas según sea necesario -->


                </tbody>
            </table>
        </div>
    </div>
</div>